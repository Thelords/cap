import fs from "node:fs/promises";
import { transform } from "lightningcss";
import { chromium } from "playwright";
import { minify } from "terser";
import {
  keys,
  shipped,
  shippedKeys,
  translations,
} from "./src/src/i18n/translations.js";

const minifyCSS = (input) => {
  const { code } = transform({
    filename: "cap.css",
    code: Buffer.from(input),
    minify: true,
    targets: {
      chrome: 90 << 16,
      firefox: 90 << 16,
      safari: (14 << 16) | (1 << 8),
    },
  });
  return code.toString();
};

const minifyJS = async (input) => {
  return (
    await minify(input, {
      compress: {
        drop_console: false,
        dead_code: true,
        reduce_vars: true,
      },
      output: {
        beautify: false,
        comments: false,
      },
      mangle: true,
    })
  ).code
    .split("\n")
    .map((e) => {
      return e.trimStart();
    })
    .join("\n");
};

console.time("build");

const rawMain = await fs.readFile("./src/src/cap.js", "utf-8");
const rawCSS = await fs.readFile("./src/src/cap.css", "utf-8");
const minifiedWorker = await minifyJS(
  await fs.readFile("./src/src/worker.js", "utf-8"),
);
const minifiedCSS = minifyCSS(rawCSS);

const keepIdx = shippedKeys.map((k) => {
  const i = keys.indexOf(k);
  if (i === -1) throw new Error(`shippedKey '${k}' not in keys`);
  return i;
});
const i18nRows = {};
for (const code of shipped) {
  if (!translations[code])
    throw new Error(`shipped lang '${code}' missing from translations`);
  const vals = keepIdx.map((i) => translations[code][i]);
  const bad = vals.find((v) => v.includes("/"));
  if (bad) throw new Error(`'${code}' string contains the "/" delimiter: ${bad}`);
  i18nRows[code] = vals.join("/");
}
const i18nJSON = JSON.stringify(i18nRows);
console.log(
  `i18n: ${shipped.length} langs x ${shippedKeys.length} keys, ${i18nJSON.length}B raw`,
);

const bundle = rawMain
  .replace("%%workerScript%%", () => JSON.stringify(minifiedWorker))
  .replace("%%capCSS%%", () => minifiedCSS)
  .replace("%%i18nKeys%%", () => shippedKeys.join(","))
  .replace("%%i18nData%%", () => i18nJSON);

await fs.writeFile("./src/cap.min.js", bundle);
await fs.writeFile("./src/cap.min.js", await minifyJS(bundle));

await fs.writeFile(
  "./src/cap-floating.min.js",
  await minifyJS(await fs.readFile("./src/src/cap-floating.js", "utf-8")),
);

console.timeEnd("build");

console.time("test");

const browser = await chromium.launch({ headless: false });
const page = await browser.newPage();

const server = Bun.serve({
  port: 3007,
  routes: {
    "/": () => {
      return new Response(Bun.file("./test.html"));
    },
    "/widget.js": () => {
      return new Response(Bun.file("./src/cap.min.js"), {
        headers: {
          "Content-Type": "application/javascript",
        },
      });
    },
    "/failed": () => {
      console.error("test failed, quitting");
      process.exit(1);
    },
    "/solved": async () => {
      await page.close();
      await browser.close();

      console.timeEnd("test");
      server.stop();

      const publish = prompt("\npublish package to npm? (y/N)");

      if (publish === "y") {
        const pkgPath = "./src/package.json";
        const originalPkg = await fs.readFile(pkgPath, "utf-8");
        const pkg = JSON.parse(originalPkg);

        const publishAs = async (name) => {
          pkg.name = name;
          await fs.writeFile(pkgPath, `${JSON.stringify(pkg, null, 2)}\n`);
          const proc = Bun.spawn({
            cmd: ["bun", "publish", "--access", "public"],
            cwd: "./src",
            stdout: "inherit",
            stderr: "inherit",
          });
          const code = await proc.exited;
          if (code !== 0) {
            throw new Error(`publish ${name} failed (exit ${code})`);
          }
        };

        try {
          await publishAs("@cap.js/widget");
          await publishAs("cap-widget");
        } finally {
          await fs.writeFile(pkgPath, originalPkg);
        }
      }

      process.exit(0);
    },
  },
});

page.goto(`http://localhost:3007/`);
